<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Welcome to GlobalStyling Saloon</title>
<link rel="stylesheet" type="text/css" href="xres/css/style.css" />
<link rel="icon" type="image/png" href="xres/images/favicon.png" />
<link type="text/css" href="css/styles.css" rel="stylesheet" media="all" />
</head>

<body>
<div id="wrapper">
	<div id="header">
    <h1><a href="index.php"><img src="xres/images/logo.png" class="logo" alt="James Buchanan Pub and Restaurant" /></a></h1>
        <ul id="mainnav">
			<li><a href="index.php">Home</a></li>
			<<li><a href="history.php">About Us</a></li>
			<li><a href="rates.php">services</a></li>
            <li class="current"><a href="location.php">location</a></li>
			<li><a href="contact.php">Contact Us</a></li>
    	</ul>
	</div>
    <div id="content">
    	<div id="gallerycontainer">
			<div class="portfolio-area" style=" padding:140px 0 20px 0;">	
			
				<iframe width="100%" height="390" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://www.google.co.ke/maps/@-1.3048035,36.8473969,11z?hl=en"></iframe><br /><small><a href="https://www.google.co.ke/maps/@-1.3048035,36.8473969,11z?hl=en">View Larger Map</a></small>
               	<div class="column-clear"></div>
            </div>
			<div class="clearfix"></div>
        </div>
    </div>
    



<div id="footer">
		<h4>Welcome &bull; <a href="contact-us.php">check-ins available  8am -10 PM  weeks days 9am to 7pm weekends &bull; </a></h4>		
		<p>&copy; Copyright 2015 GlobalStyling Saloon  | All Rights Reserved <br /></p>
	</div>

</div>
</body>
</html>
