﻿-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 26, 2015 at 02:16 PM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `shoopingcart`
--

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

CREATE TABLE IF NOT EXISTS `about` (
  `id` int(11) NOT NULL,
  `about` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `about`
--

INSERT INTO `about` (`id`, `about`) VALUES
(1, '<strong>Create a setup page and tables for the GlobalStyling appointments system</strong><br>\r\nEnsure that Heather as owner can add hair stylings and treatments (products) to the database. The products should be largely the same at each salon; however the prices should be based on local currency. The pound (£) should be used as the base currency and the system should access a web service to convert from pounds into euros and Page 3 of 4 Dynamic Websites © NCC Education Limited 2015  \r\n<br><br>\r\n<strong>Description</strong><br>\r\nThe GlobalStyling appointments system will allow users to create a record for themselves and then log in to the system to book an appointment at one of the three salons in London, Paris or New York. The system will store personal details of each customer and their email address so that they can be sent details of new hair treatments and special offers. \r\n<br><br><strong>General Information</strong><br>\r\nGlobalStyling is an international designer hair salon. The company started out from a small hairdressing business in London, UK and has built up a clientele of the rich and famous. As well as the salon in London, they now also have a French salon in Paris and a salon in the USA in New York City. All the salons offer the very best in hair styling to a set of sophisticated customers. The salon owner, Heather, has decided that it is time to enter the digital age and has asked for your help. You have been commissioned by GlobalStyling to produce a web-based application that will enable customers to book appointments in the three salons. \r\n<br><br>\r\n\r\nGlobal Styling Saloon FEATURES<br>\r\n. What have you learnt during this assignment? <br>\r\n2. How could the system be improved or further developed? <br>\r\n3. Which parts of the development did you find most difficult<br>\r\n. What have you learnt during this assignment? <br>\r\n2. How could the system be improved or further developed? <br>\r\n3. Which parts of the development did you find most difficult<br>\r\n. What have you learnt during this assignment? <br>\r\n2. How could the system be improved or further developed? <br>\r\n3. Which parts of the development did you find most difficult<br>');

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE IF NOT EXISTS `address` (
  `id` int(11) NOT NULL,
  `address` varchar(1000) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`id`, `address`) VALUES
(1, '						 						 						 Telephone Number: <br>(+254722781560) <br>\r\nEmail:<br>info@globalstyling.com<br>\r\nAddress: <br>GlobalStyling saloon, Moi Evenue, Nairobi city, Kenya 																																							');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE IF NOT EXISTS `gallery` (
  `id` int(11) NOT NULL,
  `image` varchar(300) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `image`) VALUES
(13, 'roo19.jpg'),
(14, 'room1.jpg'),
(15, 'room2.jpg'),
(16, 'room3.jpg'),
(17, 'room4.jpg'),
(18, 'room5.jpg'),
(19, 'room6.jpg'),
(20, 'room7.jpg'),
(21, 'room8.jpg'),
(22, 'room9.jpg'),
(23, 'room10.jpg'),
(24, 'room10.jpg'),
(25, 'room11.jpg'),
(26, 'room12.jpg'),
(27, 'room13.jpg'),
(28, 'room15.jpg'),
(29, 'room17.jpg'),
(30, 'room18.jpg'),
(31, 'room20.jpg'),
(32, 'room21.jpg'),
(33, 'room22.jpg'),
(34, 'room23.jpg'),
(35, 'room24.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `internet_shop`
--

CREATE TABLE IF NOT EXISTS `internet_shop` (
  `id` int(6) NOT NULL,
  `img` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `price` double NOT NULL DEFAULT '0',
  `room_number` varchar(30) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `internet_shop`
--

INSERT INTO `internet_shop` (`id`, `img`, `name`, `description`, `price`, `room_number`) VALUES
(12, 'nkm.jpg', 'Bouffant', 'It is characterst by smooth hair that i heightene and given extra fulling over teas or paddin,It iscommon form of hair style practice in Paris', 999, 'Paris'),
(13, 'n,.jpg', 'Braid', 'It is also called plait or a tresses,it type of style usually women with long hair in which a part of hair eparated strands, normally three and then plaint brauded together typically forming o braid', 1199, 'london'),
(11, 'index3.jpg', 'Bob cut', 'this is a classic hairstyle where the ends to around jaw-level aligned cl to the faci area.This style is m common among women.A hair cut far from the spike', 998, 'paris'),
(14, '481953795_d1.jpg', 'Afro', 'Big hair style mainly featured in Afro-Amere culture popular through France.This is a type of style that cannot be alter by combing or flaw iron.', 1299, 'france'),
(15, 'm.jpg', 'Beehive', 'It is a type of Hair Style which raised a the top of head by padding teasing so that the shape suggestive a beehive hence the name.', 1500, 'france'),
(16, 'gj.jpg', 'Bunches', 'Another big from London for pigtail worn unbraided alternatively name  for butch that less than quarter of inch on to ', 2299, 'london'),
(17, 'index2.jpg', 'Caesar Cut', 'It is hairstyle which and horizontall straight a pictured of bust caesar depict him wearing sultan hair manner which nnaped of the neck and requires tighter bin than ordin buns', 2499, 'paris'),
(18, 'slide3.jpg', 'cornrows', 'Hairsttyle originlly form subsahara africa popularise african americans where the hair style is braidlike into a series of French like braid locks that cling to head and travel the neck', 4485, 'france'),
(19, 'index.jpg', 'Fallera', 'It is price Leia hairs of stars w Flame.It is elaborate hairstyle  consisting two spirall buns on the either side of the head braids who around the back of the head with twisted strands of in different ', 1100, 'London'),
(20, 'slide2.jpg', 'Feathered hair', 'It is price Leia hairs of stars w Flame.It is elaborate hairstyle  consisting two spirall buns on the either side of the head braids who around the back of the head with twisted strands of in different ', 890, 'London'),
(21, 'index1.jpg', 'Finger wave', 'Big hair style mainly featured in Afro-Amere culture popular through France.This is a type of style that cannot be alter by combing or flaw iron.', 6789, 'Paris'),
(22, 'f.jpg', 'Fontage', 'Big hair style mainly featured in Afro-Amere culture popular through France.This is a type of style that cannot be alter by combing or flaw iron.', 7689, 'France');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE IF NOT EXISTS `message` (
  `message_id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(100) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`message_id`, `name`, `email`, `subject`, `message`) VALUES
(1, 'iuyyuyuyu', 'yuyuyuyu', 'yuyuyuyu', 'yuyuyuyu'),
(2, 'jkjjk', 'jkjkjk', 'jkjkjkjk', 'kjkjkjkj'),
(3, 'errer', 'dsdsds@sdsds.com', 'kkjkjkjk', 'kjkjkjkjkjkj'),
(4, '', '', '', ''),
(5, 'festo langat', 'festo@gmail.com', 'Inquiry', 'It a wonderful Saloon design');

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE IF NOT EXISTS `reservation` (
  `reservation_id` int(11) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `city` varchar(30) NOT NULL,
  `address` varchar(30) NOT NULL,
  `country` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contact` int(20) NOT NULL,
  `arrival` varchar(30) NOT NULL,
  `departure` varchar(30) NOT NULL,
  `result` int(11) NOT NULL,
  `payable` int(11) NOT NULL,
  `status` varchar(10) NOT NULL,
  `confirmation` varchar(20) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`reservation_id`, `firstname`, `lastname`, `city`, `address`, `country`, `email`, `contact`, `arrival`, `departure`, `result`, `payable`, `status`, `confirmation`) VALUES
(4, 'jkj', 'kjkjkjk', 'kjkjkj', 'jkjkjkj', 'kjkjkjk', 'email', 0, '12/12/2012', '13/12/2012', 1, 211212, 'Cancel', 'jfvby8kv'),
(3, 'argie', 'policar[io', 'bacolod', 'talisay', 'philippines', 'email', 909090909, '03/12/2012', '09/12/2012', 6, 2248, 'Cancel', 'sw8jx83n'),
(5, '', '', '', '', '', 'email', 0, '26/12/2012', '27/12/2012', 1, 0, 'active', 'sz3w0cmq'),
(6, 'hghg', 'hghghg', 'gh', 'hghgh', 'ghgh', 'email', 0, '26/12/2012', '27/12/2012', 1, 2498, 'active', '720c36aa'),
(7, 'tytyt', 'ytytyt', 'ytytyt', 'ytytyt', 'ytytyt', 'email', 0, '17/12/2012', '19/12/2012', 2, 7283, 'active', 'qie3thni'),
(8, 'festus', 'langat', 'nairobi', 'box 211', 'kenya', 'email', 725077838, '', '', 0, 2299, 'active', 'sfwbu2vu'),
(9, 'festo', 'langta', 'nairobi', 'box211', 'kenya', 'email', 0, '19/08/2015', '25/08/2015', 6, 5497, 'active', '067jo4qx'),
(10, 'festo', 'langat', 'nairobi', 'box 211', 'kenya', 'email', 725077838, '', '', 0, 699, 'Cancel', 'w4vkcs0p'),
(11, 'festo', 'langat', 'nairobi', 'box211', 'kenya', 'email', 725077838, '18/08/2015', '19/08/2015', 1, 1299, 'active', 'grmqhybm'),
(12, 'festo', 'langta', 'nairobi', 'box 211', 'kenya', 'email', 725077838, '19/08/2015', '26/08/2015', 7, 3799, 'active', 'zf2v5pw7');

-- --------------------------------------------------------

--
-- Table structure for table `rooinventory`
--

CREATE TABLE IF NOT EXISTS `rooinventory` (
  `id` int(11) NOT NULL,
  `room` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `arrival` varchar(30) NOT NULL,
  `departure` varchar(30) NOT NULL,
  `status` varchar(30) NOT NULL,
  `confirmation` varchar(30) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rooinventory`
--

INSERT INTO `rooinventory` (`id`, `room`, `qty`, `arrival`, `departure`, `status`, `confirmation`) VALUES
(1, 11, 1, '26/12/2012', '27/12/2012', 'active', '720c36aa'),
(2, 15, 1, '26/12/2012', '27/12/2012', 'active', '720c36aa'),
(3, 15, 1, '17/12/2012', '19/12/2012', 'active', 'qie3thni'),
(4, 12, 1, '17/12/2012', '19/12/2012', 'active', 'qie3thni'),
(5, 18, 1, '17/12/2012', '19/12/2012', 'active', 'qie3thni'),
(6, 16, 1, '', '', 'active', 'sfwbu2vu'),
(7, 16, 1, '19/08/2015', '25/08/2015', 'active', '067jo4qx'),
(8, 11, 1, '19/08/2015', '25/08/2015', 'active', '067jo4qx'),
(9, 17, 1, '19/08/2015', '25/08/2015', 'active', '067jo4qx'),
(10, 11, 1, '', '', 'active', 'w4vkcs0p'),
(11, 14, 1, '18/08/2015', '19/08/2015', 'active', 'grmqhybm'),
(12, 16, 1, '19/08/2015', '26/08/2015', 'active', 'zf2v5pw7'),
(13, 15, 1, '19/08/2015', '26/08/2015', 'active', 'zf2v5pw7');

-- --------------------------------------------------------

--
-- Table structure for table `slideshow`
--

CREATE TABLE IF NOT EXISTS `slideshow` (
  `id` int(11) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slideshow`
--

INSERT INTO `slideshow` (`id`, `image`) VALUES
(9, 'room11.jpg'),
(10, 'room3.jpg'),
(11, 'room18.jpg'),
(12, 'room23.jpg'),
(13, 'room22.jpg'),
(14, 'room21.jpg'),
(15, 'iMac.png');

-- --------------------------------------------------------

--
-- Table structure for table `tb_guest`
--

CREATE TABLE IF NOT EXISTS `tb_guest` (
  `user_id` int(11) NOT NULL,
  `fullname` varchar(255) CHARACTER SET cp1250 NOT NULL,
  `email` varchar(255) CHARACTER SET cp1250 NOT NULL,
  `phone` int(15) NOT NULL,
  `username` varchar(255) CHARACTER SET cp1250 NOT NULL,
  `password` varchar(255) CHARACTER SET cp1250 NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_guest`
--

INSERT INTO `tb_guest` (`user_id`, `fullname`, `email`, `phone`, `username`, `password`) VALUES
(1, 'langat', 'langat@gmail.com', 725077838, 'festo', 'festo');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `position` varchar(45) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `username`, `password`, `position`) VALUES
(1, 'admin', 'admin', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about`
--
ALTER TABLE `about`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `internet_shop`
--
ALTER TABLE `internet_shop`
  ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `img` (`img`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`message_id`);

--
-- Indexes for table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`reservation_id`);

--
-- Indexes for table `rooinventory`
--
ALTER TABLE `rooinventory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slideshow`
--
ALTER TABLE `slideshow`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_guest`
--
ALTER TABLE `tb_guest`
  ADD PRIMARY KEY (`user_id`), ADD UNIQUE KEY `email` (`email`) COMMENT 'somebody has the same username', ADD UNIQUE KEY `phone` (`phone`) COMMENT 'This number has already be taken';

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about`
--
ALTER TABLE `about`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `internet_shop`
--
ALTER TABLE `internet_shop`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `message_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `reservation`
--
ALTER TABLE `reservation`
  MODIFY `reservation_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `rooinventory`
--
ALTER TABLE `rooinventory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `slideshow`
--
ALTER TABLE `slideshow`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `tb_guest`
--
ALTER TABLE `tb_guest`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
