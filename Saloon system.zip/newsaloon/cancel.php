<meta http-equiv="refresh" content="5; url=index.php">

<div style="margin:0 auto; text-align:center;">
Canceling Reservation
<br>
<img src="ajax-loader.gif">
<br>
Pls........ wait
</div>