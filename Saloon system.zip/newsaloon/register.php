<?php
	include('db.php');
	$fname = $_POST['fname'];
	$email = $_POST['email'];	
	$phone = $_POST['phone'];
	$uname = $_POST['uname'];
	$password = $_POST['password'];
	mysql_query("INSERT INTO tb_guest (fullname, email, phone, username,password) VALUES ('$fname','$email','$phone','$uname','$password')");
	
	
	header("location:index.php");
	echo ("Registration complete!proceed to login");
?>